package com.example.t2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class Atualizar extends AppCompatActivity {
    //variáveis correspondes aos botões
    private Button btnProcurar;
    private Button btnAlterar;

    //variáveis correspondente aos campoos que serão preenchido para atualização
    private EditText nome;
    private Switch cabelo;
    private Switch barba;
    private DatePicker data_dia;
    private DatePicker data_mes;
    private DatePicker data_ano;
    private TimePicker hora_hora;
    private TimePicker hora_minuto;
    private Button btnAgendar;
    private AgendamentoDataBase db;
    private Agendamento agendamento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atualizar);

        //Variável criada para apontar para o Banco de dados
        db = new AgendamentoDataBase(this);

        //"linkando" as váriaveis com as Views no XML
        btnAlterar =(Button) findViewById(R.id.agendarAXML);
        btnProcurar = (Button) findViewById(R.id.buscarAXML);
        nome = findViewById(R.id.nomeAXML);
        cabelo = findViewById(R.id.servico_cabeloAXML);
        barba = findViewById(R.id.servico_barbaAXML);
        data_dia = findViewById(R.id.dataAXML);
        data_mes = findViewById(R.id.dataAXML);
        data_ano = findViewById(R.id.dataAXML);
        hora_hora = findViewById(R.id.horaAXML);
        hora_minuto = findViewById(R.id.horaAXML);

        //listerner do botão carrega para capturar o nome do agandamento fornecido pelo usuário
        //Se o agendamento não existe, ele limpa os campos e devolve um toast.
        //Se o agendamento não existe, ele caputara as informações do agendamento e exibe para o usuário
        btnProcurar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomeAtualiza = nome.getText().toString();
                // chama o método pesquisaAgendamento  para verificar se "nome" (registro) digitado pelo usuário existe
                // se existir o banco devolve um objeto da classe Agendamento com as informações do registro.
                agendamento = db.pesquisaAgendamento(nomeAtualiza);
                // se não existe
                if(agendamento.get_id()==0)
                { Toast.makeText(Atualizar.this,"Agendamento inexistente com este nome",Toast.LENGTH_LONG).show();
                    nome.setText("");}
                //recebe o agendamento e exibe nos campos para o usuário
                else {
                    nome.setText(agendamento.getNome());
                    cabelo.setText(agendamento.getServiço_cabelo());
                    barba.setText(agendamento.getServiço_barba());
                    hora_hora.setHour(agendamento.getHora_hora());
                    hora_minuto.setMinute(agendamento.getHora_minuto());
                    data_dia.setMinDate(agendamento.getData_dia());
                    data_mes.setMinDate(agendamento.getData_mes());
                    data_ano.setMinDate(agendamento.getData_ano());
                }
            }
        });





        //listener do botão atualiza para processar a atualização do registro na tabela
        btnAlterar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Verfica se não foi solicitado acidentalmente para atualizar sem ter carregado previamente um agendamento.
                //ou após um retorno de contato inexistente.
                if(nome.getText().length()==0){
                    Toast.makeText(Atualizar.this, "Por favor insira o nome do contato!" , Toast.LENGTH_SHORT).show();

                }
                //captura dos campos da tela os valores e modifica os valores dos campos do objeto contato retornado
                else{
                    String name = nome.getText().toString();
                    int dia = data_dia.getDayOfMonth();
                    int mes = data_mes.getMonth();
                    int ano = data_ano.getYear();
                    int hora = hora_hora.getHour();
                    int minuto = hora_minuto.getMinute();
                    String cabelo_ = cabelo.getTextOn().toString();
                    String barba_ = barba.getTextOn().toString();
                    agendamento.setNome(name);
                    agendamento.setData_dia(dia);
                    agendamento.setData_mes(mes);
                    agendamento.setData_ano(ano);
                    agendamento.setHora_hora(hora);
                    agendamento.setHora_minuto(minuto);
                    agendamento.setServiço_cabelo(cabelo_);
                    agendamento.setServiço_barba(barba_);
                    //chama o método salva agenda para a atualiação
                    long id = db.salvaAgendamento(agendamento);
                    //mensagens de retorno da operação de atualização
                    if(id!=-1)
                        Toast.makeText(Atualizar.this,"atualização realizada!",Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(Atualizar.this,"Ops! não foi possível atualizar o contato.",Toast.LENGTH_LONG).show();

                    nome.setText("");
                }}
        } );
    }

}
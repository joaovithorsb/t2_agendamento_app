package com.example.t2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;

//primeiro vamos declarar AgendamentoDataBase como filha da SQLiteOpenHelper ("extends")
public class AgendamentoDataBase extends SQLiteOpenHelper {

    //criando constantes que vão formar o "statement" de criação da tabela do banco de dados
    // e outras constantes que serão usadas
    public static final String TAG = "sql";  // static define que isso existirá para todas instâncias da classe.
    public static final String NOME_BANCO = "MeuBancodeDados.db";   // final define que o valor não pode ser alterado.
    public static final int VERSAO_BANCO = 1;
    public static final String TABLE_NAME = "agendamentos";
    public static final String COLUNA0 = "_id";
    public static final String COLUNA1 = "nome";
    public static final String COLUNA2 = "data_dia";
    public static final String COLUNA3 = "data_mes";
    public static final String COLUNA4 = "data_ano";
    public static final String COLUNA5 = "hora_hora";
    public static final String COLUNA6 = "hora_minuto";
    public static final String COLUNA7 = "serviço_cabelo";
    public static final String COLUNA8 = "serviço_barba";


    //criação do "statement que define a tabela do banco de dados"
    private static final String SQL_CREATE_TABLE =
            "CREATE TABLE " +TABLE_NAME + " ("
                    + COLUNA0 +" INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUNA1 + " TEXT,"             //Coluna1 é do tipo de texto (string)
                    + COLUNA2 + " INTEGRER,"
                    + COLUNA3 + " INTEGRER,"        //Coluna3 é do tipo inteiro (int)
                    + COLUNA4 + " INTEGRER,"
                    + COLUNA5 + " INTEGRER,"
                    + COLUNA6 + " INTEGRER,"
                    + COLUNA7 + " INTEGRER,"
                    + COLUNA8 + " INTEGRER)";

    //construtor
      public AgendamentoDataBase(@Nullable Context context) { // Declara um construtor público para a classe AgendamentoDataBase
        super(context, NOME_BANCO, null, VERSAO_BANCO); //super é usado para chamar o construtor
    }
    //Método onCreate e onUpgrade (a classe SQLiteOpenHelper pede que esses dois métodos abastratos sejam implementados de forma concreta)
    //MÉTODO onCreate CRIA A TABELA
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE);
    }

    // MÉTODO onUpgrade NÃO IREMOS MEXER MUITO POIS NAO ATUALIZAREMOS a versão NO CÓDIGO
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }

    //MÉTODO QUE SALVA AGENDAMENTO
    //ele vai receber como entrada um objeto da classe agendamento
    public long salvaAgendamento(Agendamento agendamento){
        //lê o valor de id,
        // se = 0 agendamento novo
        // se =! 0 atualização
        long id = agendamento.get_id();
        //abre a conexão com o banco de dados
        SQLiteDatabase db = getWritableDatabase();//abre a conexão com o banco de dados
        try{
            //cria a variável que aponta para o objeto ContentValues()  e que representa o conteudo do registro a ser alterado ou criado
            //em um formato que o banco de dados entende.
            ContentValues valores = new ContentValues();  // Usado para armazenar pares chave-valor

            //transfere os valores das variáveis de instancia do objeto para a variável valor na forma (chave, valor)
            valores.put(COLUNA1,agendamento.getNome());
            valores.put(COLUNA2, agendamento.getData_dia());
            valores.put(COLUNA3, agendamento.getData_mes());
            valores.put(COLUNA4, agendamento.getData_ano());
            valores.put(COLUNA5, agendamento.getHora_hora());
            valores.put(COLUNA6, agendamento.getHora_minuto());
            valores.put(COLUNA7, agendamento.getServiço_cabelo());
            valores.put(COLUNA8, agendamento.getServiço_barba());

            if(id!=0){//se já existe este agendamento e queremos simplesmente atualizá-lo
                int count = db.update(TABLE_NAME, valores, "_id =?",new String[]{String.valueOf(id)});
                return count; // retorna o numero de linhas alteradas.

            }
            else{//se não existe o contato, vamos incluí-lo na tabela.
                id = db.insert(TABLE_NAME,null,valores);
                return id; //retorna o ID da nova linha inserida ou -1 se ocorrer erro

            }
        }finally{
            db.close();//fecha a conexão
        }
    }

    //MÉTODO QUE APAGA AGENDAMENTO
    public int apagaAgendamento(String nomeAgendamento) {
        SQLiteDatabase db = getWritableDatabase();//abre a conexão com o banco de dados
        try {
            //apago o registro onde na coluna nome o valor do registro corresponde a String passada.
            int count = db.delete(TABLE_NAME, "nome=?", new String[]{nomeAgendamento});
            Log.i(TAG, "deletou registro =>" + count);
            return count;//retorna zero se não houver registro que coincida com o valor passado para o método.
        } finally {
            db.close();//fecha a conexão
        }
    }

    //MÉTODO QUE DEVOLVE UM ARRAY DE AGENDAMENTOS (USANDO QUERY)
    public ArrayList<Agendamento> findAll() {
        //Primeiro de tudo: abrir a conexão
        SQLiteDatabase db = getWritableDatabase();
        //Declarando o ArrayList de objetos do tipo Agendamento.
        ArrayList<Agendamento> lista = new ArrayList<>();
        try {
            //colocando o valor dos campos em null, retorna todos os registros da tabela.
            Cursor c = db.query(TABLE_NAME, null, null, null, null, null, null);
            if (c.moveToFirst()) {//move o cursor para o primeiro registro

                //laço do while para correr todos os registros e formar o Array que representa a lista de registros.
                do {
                    int id = c.getInt(c.getColumnIndexOrThrow("_id"));
                    String nome = c.getString(c.getColumnIndexOrThrow("nome"));
                    int data_dia = c.getInt(c.getColumnIndexOrThrow("data_dia"));
                    int data_mes = c.getInt(c.getColumnIndexOrThrow("data_mes"));
                    int data_ano = c.getInt(c.getColumnIndexOrThrow("data_ano"));
                    int hora_hora = c.getInt(c.getColumnIndexOrThrow("hora_hora"));
                    int hora_minuto = c.getInt(c.getColumnIndexOrThrow("hora_minuto"));
                    String serviço_cabelo = c.getString(c.getColumnIndexOrThrow("serviço_cabelo"));
                    String serviço_barba = c.getString(c.getColumnIndexOrThrow("serviço_barba"));

                    Agendamento currentAgend = new Agendamento(id, nome, data_dia, data_mes, data_ano, hora_hora, hora_minuto,serviço_cabelo, serviço_barba);
                    lista.add(currentAgend);

                } while (c.moveToNext());

            }
            return lista;//retorna o Array contendo os contatos
        } finally {
            db.close();//fecha a conexão
        }
    }

    //MÉTODO QUE PESQUISA AGENDAMENTO (procurando pelo nome???)
    public Agendamento pesquisaAgendamento(String nomeAgendamento) {
        SQLiteDatabase db = getWritableDatabase(); //Abre conexão
        String nome;
        int data_dia;
        int data_mes;
        int data_ano;
        int hora_hora;
        int hora_minuto;
        String serviço_cabelo;
        String serviço_barba;
        int id;

        try {
            Cursor c = db.query(TABLE_NAME, null,"nome=?", new String[]{nomeAgendamento}, null, null, null, null);
            if(c.moveToFirst()) {//verifica se o contato existe, se sim extrai os valores para criação de um objeto agendamento com os valores
                id= c.getInt(c.getColumnIndexOrThrow("_id"));
                nome = c.getString(c.getColumnIndexOrThrow("nome"));
                data_dia = c.getInt(c.getColumnIndexOrThrow("data_dia"));
                data_mes = c.getInt(c.getColumnIndexOrThrow("data_mes"));
                data_ano = c.getInt(c.getColumnIndexOrThrow("data_ano"));
                hora_hora = c.getInt(c.getColumnIndexOrThrow("hora_hora"));
                hora_minuto = c.getInt(c.getColumnIndexOrThrow("hora_minuto"));
                serviço_cabelo = c.getString(c.getColumnIndexOrThrow("serviço_cabelo"));
                serviço_barba = c.getString(c.getColumnIndexOrThrow("serviço_barba"));

            }
            //Se não for encontrado, define  valores dummy para criação de um objeto
            //pois o método retorna um objeto do tipo agendamento
            else{
                id = 0;
                nome = "dummy";
                data_dia = 0 ;
                data_mes = 0 ;
                data_ano = 0 ;
                hora_hora = 0;
                hora_minuto = 0;
                serviço_barba = "empty";
                serviço_cabelo = "empty";
            }
            Agendamento agendamento = new Agendamento(id, nome, data_dia, data_mes, data_ano, hora_hora, hora_minuto, serviço_cabelo, serviço_barba);
            return agendamento;
        } finally {
            db.close();
        }
    }
}

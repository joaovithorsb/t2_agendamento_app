package com.example.t2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login_barbeiro extends AppCompatActivity {

    private EditText login;
    private EditText senha;
    private Button btnEntrar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_barbeiro2);


        login = findViewById(R.id.usernameLXML);
        senha = findViewById(R.id.senhaLXML);
        btnEntrar = findViewById(R.id.loginLXML);

        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (senha.getText().toString().equals("12345") && login.getText().toString().equals("joao")){ // Se a senha for igual a 12345 e login: joão
                        Intent it = new Intent(login_barbeiro.this, Barbeiro.class);             // vai abrir a activity Barbeiro
                        startActivity(it);
            }   else {
                    Toast.makeText(login_barbeiro.this, "Login ou senha incorretos", Toast.LENGTH_SHORT).show();
                    }
        }
    });
}}
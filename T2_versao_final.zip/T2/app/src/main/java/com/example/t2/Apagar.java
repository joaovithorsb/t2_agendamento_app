package com.example.t2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Apagar extends AppCompatActivity {

    //variavel para inserir o nome do contato para apagar
    private EditText agenda;

    //botão para apagar
    private Button btnApagar;
    private AgendamentoDataBase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apagar);

        db = new AgendamentoDataBase(this);
        agenda =  findViewById(R.id.nomeAXML);
        btnApagar = findViewById(R.id.apagarAXML);

        //listener do botão apagar chama o método Apaga Agendamento da classe AgendamentoDataBase
        btnApagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //se não encontrar o registro devolve 0, senão devolve -1
                int count = db.apagaAgendamento(agenda.getText().toString());
                //não encontrou contato
                if (count == 0) {
                    Toast.makeText(Apagar.this, "Agendamento Inexistente!", Toast.LENGTH_SHORT).show();
                    agenda.setText("");
                    // encontrou e apagou
                } else {
                    Toast.makeText(Apagar.this, "Agendamento apagado!", Toast.LENGTH_SHORT).show();
                    agenda.setText("");
                }
            }
        });
    }


}
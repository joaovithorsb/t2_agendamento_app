package com.example.t2;

import androidx.annotation.NonNull;

public class Agendamento {

    //declarando as variáveis que logo vamos colocar no DB através de setter and getters
    private long _id;
    private String nome;
    private String serviço_cabelo;
    private String serviço_barba;
    private int data_dia;
    private int data_mes;
    private int data_ano;
    private int hora_hora;
    private int hora_minuto;


    //construtores para passar valores para o objeto
    public Agendamento(long _id, String nome, int data_dia,int data_mes, int data_ano,int hora_hora,int hora_minuto, String serviço_cabelo, String serviço_barba) {
        this._id = _id;
        this.nome = nome;
        this.data_dia = data_dia;
        this.data_mes = data_mes;
        this.data_ano = data_ano;
        this.hora_hora = hora_hora;
        this.hora_minuto = hora_minuto;
        this.serviço_cabelo = serviço_cabelo;
        this.serviço_barba = serviço_barba;
    }

    // gets e sets gerados automaticamente (botão direito<generate<gets and setters) (um get e um set para cada variável)
    public long get_id() {
        return _id;
    }

    public void set_id(long _id) {
        this._id = _id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getServiço_cabelo() {
        return serviço_cabelo;
    }

    public void setServiço_cabelo(String serviço_cabelo) {
        this.serviço_cabelo = serviço_cabelo;
    }

    public String getServiço_barba() {
        return serviço_barba;
    }

    public void setServiço_barba(String serviço_barba) {
        this.serviço_barba = serviço_barba;
    }

    public int getData_dia() {
        return data_dia;
    }

    public void setData_dia(int data_dia) {
        this.data_dia = data_dia;
    }

    public int getData_mes() {
        return data_mes;
    }

    public void setData_mes(int data_mes) {
        this.data_mes = data_mes;
    }

    public int getData_ano() {
        return data_ano;
    }

    public void setData_ano(int data_ano) {
        this.data_ano = data_ano;
    }

    public int getHora_hora() {
        return hora_hora;
    }

    public void setHora_hora(int hora_hora) {
        this.hora_hora = hora_hora;
    }

    public int getHora_minuto() {
        return hora_minuto;
    }

    public void setHora_minuto(int hora_minuto) {
        this.hora_minuto = hora_minuto;
    }

    //Damos esse override para sobreescrever. Onde ia retornar o endereço de memória, vai retornar os dados deste modo que definimos abaixo
    @NonNull
    @Override
    public String toString() {
        return  "\n"+ "Nome :"+nome+ "\n"+
                "Dia :"+data_dia+"\n"+
                "Mês :"+data_mes+"\n"+
                "Ano :"+data_ano+"\n"+
                "Hora :"+hora_hora+"\n"+
                "Minuto :"+hora_minuto+"\n"+
                "Cabelo :"+serviço_cabelo+"\n"+
                "Barba :"+serviço_barba+"\n";
    }
}

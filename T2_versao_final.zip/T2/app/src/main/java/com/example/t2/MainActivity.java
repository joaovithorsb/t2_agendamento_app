package com.example.t2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.core.view.WindowCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.t2.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    // ?

    // Criando as variáveis para cada Imagem_botão no XML
    private ImageButton btnCliente;
    private ImageButton btnBarbeiro;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        // ?

        // 2  "linkando" as váriaveis com as Views no XML
        btnCliente=(ImageButton)findViewById(R.id.clienteXML);
        btnBarbeiro=(ImageButton)findViewById(R.id.barbeiroXML);


        // Criando um listener para disparar a ação: abrir activity do cliente
        btnCliente.setOnClickListener(new View.OnClickListener() {      // Para btnCliente ter uma ação
            @Override
            public void onClick(View view) {
                Intent it = new Intent(MainActivity.this, Cliente.class); // intents permitem iniciar uma atividade
                startActivity(it); // Nesse caso a atividade que disparou foi entrar na activity Cliente (programação Cliente.java)
            }
        });
        // Criando um listener para disparar a ação: abrir activity do login_barbeiro
        btnBarbeiro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(MainActivity.this, login_barbeiro.class);
                startActivity(it); //Nesse caso a atividade que disparou foi entrar na activity login_barbeiro (programação login_barbeiro.java)
            }
        });
    }

    //MENU: ACESSO ÀS REDES SOCIAIS DO BARBEIRO
    @Override
    public boolean onCreateOptionsMenu(Menu menu) { // Criando o menu e associando ao XML
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) { // Fazendo a função do Menu

        int id = item.getItemId();  // getItemId() consulta o ID para o item de menu selecionado, que é atribuído a cada item de menu no XML

        if (id == R.id.redessociaisXML) {
            //criação da intent para abrir as redes sociais
            Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/barbeariabora/"));
            startActivity(webIntent);
        }

        return super.onOptionsItemSelected(item);
    }
}
package com.example.t2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.audiofx.Visualizer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
public class Barbeiro extends AppCompatActivity {

    private ImageButton btnAgendar;
    private ImageButton btnApagar;
    private ImageButton btnVisualizar;
    private ImageButton btnAtualizar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_barbeiro);

        //Associando às variáveis os xml
        btnAgendar=(ImageButton)findViewById(R.id.agendarBXML);
        btnApagar=(ImageButton)findViewById(R.id.apagarBXML);
        btnVisualizar=(ImageButton)findViewById(R.id.visualizarBXML);
        btnAtualizar=(ImageButton)findViewById(R.id.atualizarBXML);

        // Criando um listener para disparar a ação: abrir activity Agendar
        btnAgendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(Barbeiro.this, Cliente.class);
                startActivity(it);
            }
        });
        // Criando um listener para disparar a ação: abrir activity Apagar
        btnApagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(Barbeiro.this, Apagar.class);
                startActivity(it);
            }
        });
        // Criando um listener para disparar a ação: abrir activity Visualizar
        btnVisualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(Barbeiro.this, ExibeAgenda.class);
                startActivity(it);
            }
        });
        // Criando um listener para disparar a ação: abrir activity Atualizar
        btnAtualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(Barbeiro.this, Atualizar.class);
                startActivity(it);
            }
        });
    }
}
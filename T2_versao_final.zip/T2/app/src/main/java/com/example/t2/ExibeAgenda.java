package com.example.t2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ExibeAgenda extends AppCompatActivity {
    //listview para exibir a lista de Agendamentos
    private ListView minhaLista;

    //adapter da listView
    private ArrayAdapter adapter;

    //array para a lista de agendamentos
    private static ArrayList<Agendamento> exibeLista;

    private AgendamentoDataBase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exibe_agenda);

        db = new AgendamentoDataBase(this);

        minhaLista = (ListView) findViewById(R.id.listViewXML);
        //chama o método findAll que devolve um array e guarda em exibeLista
        exibeLista = db.findAll();
        //criação de uma instância de um ListAdapter utilizando um layout nativo
        adapter = new ArrayAdapter<Agendamento>(this, android.R.layout.simple_list_item_1, exibeLista);

        //associação a ListView com o adapter
        minhaLista.setAdapter(adapter);
    }
}
package com.example.t2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TimePicker;
import android.widget.Toast;

public class Cliente extends AppCompatActivity {
    //declaração das variáveis
    private EditText nome;
    private Switch cabelo;
    private Switch barba;
    private DatePicker data_dia;
    private DatePicker data_mes;
    private DatePicker data_ano;
    private TimePicker hora_hora;
    private TimePicker hora_minuto;
    private Button btnAgendar;
    // private AgendamentoDataBase db;
    private AgendamentoDataBase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente);

        //associando a variável db a um novo objeto  da classe que implementa o banco de dados.
        db = new AgendamentoDataBase(this);
        //"linkando" as váriaveis com as Views no XML
        nome = findViewById(R.id.nomeCXML);
        cabelo = findViewById(R.id.servico_cabeloCXML);
        barba = findViewById(R.id.servico_barbaCXML);
        data_dia = findViewById(R.id.dataCXML);
        data_mes = findViewById(R.id.dataCXML);
        data_ano = findViewById(R.id.dataCXML);
        hora_hora = findViewById(R.id.horaCXML);
        hora_minuto = findViewById(R.id.horaCXML);
        btnAgendar = findViewById(R.id.agendarCXML);

        //implementando o Listener do botão Agendar.
        btnAgendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //verifica se houve tentativa de cadastro sem preenchimento de todos os campos
                if (nome.getText().length() == 0 ) {
                    Toast.makeText(Cliente.this, "Por favor preencha o nome", Toast.LENGTH_SHORT).show();

                } else {
                    //Convertendo os conteúdos do activity_cliente.xml para variáveis do JAVA
                    String name = nome.getText().toString();
                    // Separando a roleta da data e hora em dia, mês, ano, hora e minuto
                    int dia = data_dia.getDayOfMonth(); // A parte de dia do DatePicker para uma variavel tipo inteiro
                    int mes = data_mes.getMonth();
                    int ano = data_ano.getYear();
                    int hora = hora_hora.getHour(); // A parte de hora do TimePicker para uma variavel tipo inteiro
                    int minuto = hora_minuto.getMinute();
                    String cabelo_ = cabelo.getTextOn().toString(); // Passando o Switch para uma String
                    String barba_ = barba.getTextOn().toString();

                    //cria um novo objeto da classe Agendamento com as informações para serem inseridas na tabela do banco dados
                    Agendamento cadastro = new Agendamento(0, name, dia, mes, ano, hora, minuto, cabelo_, barba_);
                    // chama o método salavaAgendamento do AgendamentoDataBase para a inserção  desses novos dados na tabela
                    long id = db.salvaAgendamento(cadastro);
                    if (id != -1)
                        Toast.makeText(Cliente.this, "agendamento realizado!", Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(Cliente.this, "Ops! não foi possível agendar", Toast.LENGTH_LONG).show();

                    //limpa as caixa de texto para um novo cadastro.
                    nome.setText("");
                }
            }
        });
    }
}



